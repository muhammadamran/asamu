<style>
   .hero-image {
      background-image: url("<?= base_url('modes/images/asamu/bg.png') ?>"), url("<?= base_url('modes/images/asamu/bg.png') ?>");
      background-color: #090078;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
      padding: 82px;
   }
</style>
<!-- HEADER -->
<div class="breadcrumb-area bg-img bg-black-overlay section-padding-130 hero-image">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-12 col-sm-9 col-xl-6">
            <div class="breadcrumb-content text-center">
               <div class="heading_container heading_center">
                  <h2>
                     TEAM OF <span>EXPERT</span>
                  </h2>
                  <p>
                     There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration
                  </p>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- END HEADER -->
<section class="service_section layout_padding">
   <div class="service_container">
      <div class="container ">
         <!-- <div class="heading_container heading_center">
            <h2>
               Our <span>Services</span>
            </h2>
            <p>
               There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration
            </p>
         </div> -->
         <div class="row">
            <div class="col-sm-12 col-lg-12 ">
               <img src="<?= base_url('modes/svg/design-team-animate.svg'); ?>" alt="" srcset="">
            </div>
         </div>
      </div>
   </div>
</section>